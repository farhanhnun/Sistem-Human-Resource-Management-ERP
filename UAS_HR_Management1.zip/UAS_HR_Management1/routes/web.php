<?php

use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\PayrollController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\RiwayatPekerjaanController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Redirect ke halaman karyawan sebagai halaman default
Route::get('/', function () {
    return redirect()->route('karyawan.index');
});

// Resource routes untuk Department, Staff, dan Attendance
Route::resource('department', DepartmentController::class);
Route::resource('karyawan', StaffController::class);
Route::resource('attendance', AttendanceController::class);

// Payroll routes
Route::prefix('daftargaji')->group(function () {
    Route::get('/', [PayrollController::class, 'index'])->name('payroll.index');
    Route::get('/create', [PayrollController::class, 'create'])->name('payroll.create');
    Route::post('/', [PayrollController::class, 'store'])->name('payroll.store');
    Route::get('/{id}/edit', [PayrollController::class, 'edit'])->name('payroll.edit');
    Route::put('/{id}', [PayrollController::class, 'update'])->name('payroll.update');
    Route::delete('/{id}', [PayrollController::class, 'destroy'])->name('payroll.destroy');
});


Route::get('/get-staff/{id}', [StaffController::class, 'getStaff'])->name('get.staff');


Route::prefix('riwayatpekerjaan')->group(function () {
    Route::get('/', [RiwayatPekerjaanController::class, 'index'])->name('riwayatpekerjaan.index');
    Route::get('/add', [RiwayatPekerjaanController::class, 'create'])->name('riwayatpekerjaan.add');
    Route::post('/store', [RiwayatPekerjaanController::class, 'store'])->name('riwayatpekerjaan.store');
    Route::get('/{riwayatpekerjaan}/edit', [RiwayatPekerjaanController::class, 'edit'])->name('riwayatpekerjaan.edit');
    Route::put('/{riwayatpekerjaan}', [RiwayatPekerjaanController::class, 'update'])->name('riwayatpekerjaan.update');
    Route::delete('/{riwayatpekerjaan}', [RiwayatPekerjaanController::class, 'destroy'])->name('riwayatpekerjaan.destroy');
});

// Route untuk halaman staff
Route::get('/staff', function () {
    return view('staff.staff');
})->name('staff');
