<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content -->
<div class="content">
    <h2 class="mb-4">Dashboard Admin</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-users"></i>
                    <h5>Total Karyawan</h5>
                    <p><b>2</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-building"></i>
                    <h5>Departemen</h5>
                    <p><b>4</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-calendar-check"></i>
                    <h5>Hadir Hari Ini</h5>
                    <p><b>45</b></p>
                </div>
            </div>
        </div>
    </div><br>
    <div class="container-fluid">
        <form class="d-flex" action="<?php echo e(route('attendance.index')); ?>" method="GET" role="search">
          <input class="form-control me-1" type="search" name="cari-nama" placeholder="Search by Name" aria-label="Search" style="font-weight: 400;">
          <input class="form-control me-1" type="date" name="date" style="font-weight: 400;">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </div>

    <div style="display: flex; justify-content: space-between; align-items: end;">
        <h2 class="mt-4">Data Hadir Karyawan</h2>
        <div><a href="<?php echo e(route('attendance.create')); ?>" class="btn btn-success">Add Data attendance</a></div>
    </div>
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Tanggal Absen</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->staff->name); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($item->attendance_date))); ?></td>
                    <td><?php echo e($item->status); ?></td>
                  
                    
                <td>
                   
                    <a href="<?php echo e(route('attendance.edit',$item->id)); ?>" class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></a>
                </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\kuliah\UAS_HR_Management\resources\views/attendance/kehadiran.blade.php ENDPATH**/ ?>