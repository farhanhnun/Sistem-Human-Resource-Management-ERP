<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>" class="active"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>  

<!-- Content -->
<div class="content">
    <h2 class="mb-4"><b>Input Kehadiran Karyawan</b></h2>
    
    <div style="display: flex; justify-content:space-evenly; align-items: end;">
        <h2 class="mt-2">Tanggal Absensi</h2>
        <div> <input type="date" id="tgl-absen"></div>
    </div>
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tanggal Absensi</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <form  action="<?php echo e(route('attendance.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><input type="hidden" name="name[]" value="<?php echo e($data->id); ?>" style="border: 0;"><?php echo e($data->name); ?></td>
                        <td><input type="date" name="attendance_date[]" style="border: 0;" readonly></td>
                        <td><select type="text" name="status[]">
                        <option value="Hadir">Hadir</option>    
                        <option value="Sakit">Sakit</option>    
                        <option value="Izin">Izin</option>    
                        <option value="Alpa">Alpa</option>    
                        </select></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div style="display: flex; justify-content:flex-end;">
        <button type="submit" class="btn btn-success"><i class="fa-regular fa-floppy-disk"></i> Save</button>
        </div>
    </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script>
    // Set attendance_date value based on tgl-absen on document load
    document.addEventListener('DOMContentLoaded', function() {
      const tglAbsenInput = document.getElementById('tgl-absen');
      const attendanceDateInputs = document.querySelectorAll('input[name="attendance_date[]"]');
      tglAbsenInput.addEventListener('change', function() {
        attendanceDateInputs.forEach(input => input.value = this.value);
      });
    });
  </script><?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/attendance/add.blade.php ENDPATH**/ ?>