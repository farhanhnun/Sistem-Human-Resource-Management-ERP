<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Gaji Karyawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji" class="active"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content mt-1">
    <h2 class="mb-2 text-center"><b>Edit Gaji Karyawan</b></h2>
    <div class="container bg-light p-5 rounded shadow-lg">
        <form action="<?php echo e(route('payroll.update', $payroll->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- ID Staff Dropdown -->
            <div class="row mb-3">
                <label for="staff_id" class="col-sm-3 col-form-label">ID Staff</label>
                <div class="col-sm-9">
                    <select id="staff_id" class="form-select" name="staff_id" required>
                        <option value="">Pilih ID Staff</option>
                        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($staff->id); ?>" <?php echo e($payroll->staff_id == $staff->id ? 'selected' : ''); ?>>
                                <?php echo e($staff->id); ?> - <?php echo e($staff->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Tanggal Gaji -->
            <div class="row mb-3">
                <label for="pay_date" class="col-sm-3 col-form-label">Tanggal Gaji</label>
                <div class="col-sm-3">
                    <input type="date" class="form-control" id="pay_date" name="pay_date" value="<?php echo e($payroll->pay_date); ?>" required>
                </div>
            </div>

            <!-- Jumlah Gaji -->
            <div class="row mb-3">
                <label for="amount" class="col-sm-3 col-form-label">Jumlah Gaji</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="amount" name="amount" value="<?php echo e($payroll->amount); ?>" required>
                </div>
            </div>

            <!-- Bonus -->
            <div class="row mb-3">
                <label for="bonus" class="col-sm-3 col-form-label">Bonus</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="bonus" name="bonus" value="<?php echo e($payroll->bonus); ?>" required>
                </div>
            </div>

            <!-- Potongan -->
            <div class="row mb-3">
                <label for="deduction" class="col-sm-3 col-form-label">Potongan</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="deduction" name="deduction" value="<?php echo e($payroll->deduction); ?>" required>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-3">
                <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Simpan Perubahan
                </button>
                <a href="<?php echo e(route('payroll.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-sign-out-alt"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/daftargaji/edit.blade.php ENDPATH**/ ?>