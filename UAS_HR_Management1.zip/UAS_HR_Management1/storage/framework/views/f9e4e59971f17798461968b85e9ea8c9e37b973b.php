<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content -->
<div class="content">
    <h2 class="mb-4">Dashboard Admin</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-users"></i>
                    <h5>Total Karyawan</h5>
                    <p><b>2</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-building"></i>
                    <h5>Departemen</h5>
                    <p><b>4</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-calendar-check"></i>
                    <h5>Hadir Hari Ini</h5>
                    <p><b>45</b></p>
                </div>
            </div>
        </div>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: end;">
        <h2 class="mt-4">Data Karyawan</h2>
        <div><a href="<?php echo e(route('karyawan.create')); ?>" class="btn btn-success">Add Karyawan</a></div>
    </div>
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    
                    <th>Posisi</th>
                    <th>Departemen</th>
                    <th>Tanggal Perekrutan</th>
                    <th>Gaji</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                
                <tr>
                    <td>$data->id</td>
                    <td>$data->name</td>
                    <td>$data->email</td>
                    <td>$data->position</td>
                    <td>$data->department->name</td>
                    <td> \Carbon\Carbon::parse($data->hire_date)->format('d-m-Y') </td>
                    <td>Rp. &nbsp; number_format($data->salary, 2, ',', '.') </td>
                    
                <td>
                   
                    <a href="" class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></a>
                    <a href="" class="btn btn-danger btn-sm">
                    <i class="fas fa-trash"></i></a>
                </td>

                </tr>
               
                
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\kuliah\UAS_HR_Management\resources\views/kehadiran.blade.php ENDPATH**/ ?>