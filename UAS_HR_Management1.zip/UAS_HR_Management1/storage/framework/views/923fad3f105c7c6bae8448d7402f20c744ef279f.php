<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

</head>
<body>
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="<?php echo e(route('riwayatpekerjaan.index')); ?>" class="active"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<!-- Main Content -->
<div class="content">
    <h2><b>Riwayat Pekerjaaan</b></h2>
    <?php $__currentLoopData = $riwayatpekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" value="<?php echo e($jobHistory->id); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="table-container">
        <a href="<?php echo e(route('riwayatpekerjaan.add')); ?>" class="btn btn-sm  btn-success float-end me-2"><i class="fa fa-plus"></i> Tambah</a>
       <table class="table table-bordered mt-5">
    <thead>
        <tr>
            <th>Nama Karyawan</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Position</th>
            <th>Department</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $riwayatpekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                 <td><?php echo e($jobHistory->staff->name ?? 'N/A'); ?></td>
                <td><?php echo e($jobHistory->start_date); ?></td>
                <td><?php echo e($jobHistory->end_date); ?></td>
                <td><?php echo e($jobHistory->position); ?></td>
                <td><?php echo e($jobHistory->department->name); ?></td>
                <td>
                    <a href="<?php echo e(route('riwayatpekerjaan.edit', $jobHistory->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>

                    <form action="<?php echo e(route('riwayatpekerjaan.destroy', $jobHistory->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus riwayat pekerjaan ini?');"><i class="fas fa-trash"></i> Hapus</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
    </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/riwayatpekerjaan/riwayatpekerjaan.blade.php ENDPATH**/ ?>