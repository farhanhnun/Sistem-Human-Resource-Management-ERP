<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->
<div class="content mt-1">
    <h2 class="mb-2 text-center"><b>Tambah Data Karyawan</b></h2>
    <div class="container bg-light p-5 rounded shadow-lg">
        <form action="<?php echo e(route('karyawan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <label for="name" class="col-sm-3 col-form-label">Nama Karyawan</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="name" placeholder="Nama Karyawan" required>
                </div>
            </div>

            <div class="row mb-3">
                <label for="email" class="col-sm-3 col-form-label">Email Karyawan</label>
                <div class="col-sm-9">
                    <input type="email" class="form-control" name="email" placeholder="Email Karyawan">
                </div>
            </div>

            <div class="row mb-3">
                <label for="hire_date" class="col-sm-3 col-form-label">Tanggal Masuk</label>
                <div class="col-sm-3">
                    <input type="date" class="form-control" name="hire_date">
                </div>
            </div>

            <div class="row mb-3">
                <label for="department_name" class="col-sm-3 col-form-label">Nama Departemen</label>
                <div class="col-sm-9">
                    <select class="form-select" name="department_id" id="department_id" onchange="updatePositions()" required>
                        <option value="" disabled selected>Pilih Departemen</option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <label for="position" class="col-sm-3 col-form-label">Posisi</label>
                <div class="col-sm-9">
                    <select class="form-select" name="position" id="position">
                        <option value="" disabled selected>Pilih Posisi</option>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <label for="salary" class="col-sm-3 col-form-label">Gaji Karyawan</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" step="0.1" name="salary">
                </div>
            </div>

            <div class="d-flex justify-content-end gap-3">
                <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Submit
                </button>
                <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-sign-out-alt"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</div>

<script>
    // Data Posisi berdasarkan Departemen
    const departmentPositions = {
        1: ['Manager', 'HR Generalist', 'HR Manager', 'Compensation and Benefits Specialist'],
        2: ['Manager', 'Accountant', 'Tax Specialist', 'Chief Financial Officer (CFO)'],
        3: ['Manager', 'Marketing Manager', 'Brand Manager', 'Digital Marketing Specialist', 'Social Media Manager'],
        4: ['Manager', 'Software Developer', 'Network Admin', 'Database Administrator', 'Data Analyst'],
    };

    // Fungsi untuk update dropdown Posisi berdasarkan Departemen yang dipilih
    function updatePositions() {
        const departmentId = document.getElementById('department_id').value;
        const positionSelect = document.getElementById('position');

        // Kosongkan opsi yang ada di dropdown posisi
        positionSelect.innerHTML = '<option value="" disabled selected>Pilih Posisi</option>';

        if (departmentId && departmentPositions[departmentId]) {
            const positions = departmentPositions[departmentId];
            positions.forEach(function(position) {
                const option = document.createElement('option');
                option.value = position;
                option.textContent = position;
                positionSelect.appendChild(option);
            });
        }
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/staff/add.blade.php ENDPATH**/ ?>