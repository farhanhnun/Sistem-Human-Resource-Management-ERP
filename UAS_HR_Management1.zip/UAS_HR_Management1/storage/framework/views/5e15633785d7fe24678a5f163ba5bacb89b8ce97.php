<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kehadiran - HR Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>" class="active"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>  

    <!-- Main Content -->
    <div class="content mt-1">
        <h2 class="mb-2 text-center"><b>Edit Kehadiran Karyawan</b></h2>
        <div class="container bg-light p-5 rounded shadow-lg">
            <form action="<?php echo e(route('attendance.update',$attendance->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Nama Staff (tidak dapat diubah) -->
                <div class="row mb-3">
                    <label for="name" class="col-sm-3 col-form-label">Nama</label>
                    <div class="col-sm-9">
                        <input type="hidden" class="form-control" name="name" value="<?php echo e($attendance->staff_id); ?>" required>
                        <input type="text" class="form-control" name="nameDisplay" value="<?php echo e($attendance->staff->name); ?>" readonly required>
                    </div>
                </div>

                <!-- Tanggal Absen (tidak dapat diubah) -->
                <div class="row mb-3">
                    <label for="attendance_date" class="col-sm-3 col-form-label">Tanggal</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" name="attendance_date" value="<?php echo e($attendance->attendance_date); ?>" readonly required>
                    </div>
                </div>

                <!-- Status Kehadiran (yang dapat diubah) -->
                <div class="row mb-3">
                    <label for="status" class="col-sm-3 col-form-label">Status Kehadiran</label>
                    <div class="col-sm-9">
                        <select name="status" class="form-control" required>
                            <option value="Hadir" <?php echo e($attendance->status == 'Hadir' ? 'selected' : ''); ?>>Hadir</option>    
                            <option value="Sakit" <?php echo e($attendance->status == 'Sakit' ? 'selected' : ''); ?>>Sakit</option>    
                            <option value="Izin" <?php echo e($attendance->status == 'Izin' ? 'selected' : ''); ?>>Izin</option>    
                            <option value="Alpa" <?php echo e($attendance->status == 'Alpa' ? 'selected' : ''); ?>>Alpa</option>    
                        </select>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="d-flex justify-content-end gap-3">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-sign-out-alt"></i> Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/attendance/edit.blade.php ENDPATH**/ ?>