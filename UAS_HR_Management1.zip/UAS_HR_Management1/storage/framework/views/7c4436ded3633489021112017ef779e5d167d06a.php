<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #007bff;
            color: #fff;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            position: fixed;
            height: 100%;
            padding-top: 20px;
        }
        .sidebar a {
            color: #dcdcdc;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background-color: #007bff;
            color: #fff;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .card {
            margin: 10px;
            border-radius: 10px;
        }
        .table {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            overflow: hidden;
        }
        .table th, .table td {
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Human Resource Management</a>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <a href="/karyawan">Karyawan</a>
    <a href="/departemen">Departemen</a>
    <a href="#">Pekerjaan</a>
    <a href="#">Kehadiran</a>
    <a href="#">Penggajian</a>
</div>

<!-- Main Content -->
<div class="content">
    <h1>Dashboard Karyawan</h1>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Total Karyawan</h5>
                    <i class="fa-solid fa-user"></i>
                    <p class="card-text">50</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Departemen</h5>
                    <p class="card-text">4</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Hadir Hari Ini</h5>
                    <p class="card-text">45 Karyawan</p>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mt-4">Data Karyawan</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Posisi</th>
                <th>Departemen</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>John Doe</td>
                <td>john.doe@example.com</td>
                <td>Manager</td>
                <td>HR</td>
                <td>
                    <button class="btn btn-primary btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Hapus</button>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Jane Smith</td>
                <td>jane.smith@example.com</td>
                <td>Developer</td>
                <td>IT</td>
                <td>
                    <button class="btn btn-primary btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Hapus</button>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\UAS_HR_Management\resources\views/karyawan.blade.php ENDPATH**/ ?>