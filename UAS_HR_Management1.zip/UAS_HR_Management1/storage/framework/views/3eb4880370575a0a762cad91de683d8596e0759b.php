<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>


    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"   class="active"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content">
    <h2><b>Daftar Gaji Karyawan</b></h2>
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-money-bill-wave"></i>
                    <h5>Total Gaji Dibayarkan</h5>
                    <p class="text-success">Rp 7.950.000</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-gift"></i>
                    <h5>Total Bonus</h5>
                    <p class="text-warning">Rp 800.000</p>
                </div>
            </div>
        </div>
    </div>

    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Tanggal Pembayaran</th>
                    <th>Gaji Pokok</th>
                    <th>Bonus</th>
                    <th>Potongan</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>202302090</td>
                    <td>John Doe</td>
                    <td>2024-12-25</td>
                    <td>Rp 4.000.000</td>
                    <td>Rp 500.000</td>
                    <td>Rp 200.000</td>
                    <td>Rp 4.300.000</td>
                    <td>
                    <button class="btn btn-success btn-sm">
                    <i class="fa-solid fa-user-plus"></i></button>
                    <button class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></button>
                    </td>
                </tr>
                <tr>
                    <td>202302080</td>
                    <td>Jane Smith</td>
                    <td>2024-12-25</td>
                    <td>Rp 3.500.000</td>
                    <td>Rp 300.000</td>
                    <td>Rp 150.000</td>
                    <td>Rp 3.650.000</td>
                    <td>
                    <button class="btn btn-success btn-sm">
                    <i class="fa-solid fa-user-plus"></i></button>
                    <button class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/daftargaji.blade.php ENDPATH**/ ?>