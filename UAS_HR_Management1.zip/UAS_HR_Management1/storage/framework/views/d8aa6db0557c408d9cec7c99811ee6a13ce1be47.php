<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #00008B;
            color: #fff;
        }
        .sidebar {
            width: 250px;
            background-color: #4169E1;
            color: #fff;
            position: fixed;
            height: 100%;
            padding-top: 20px;
        }
        .sidebar a {
            color: #dcdcdc;
            text-decoration: none;
            display: block;
            padding: 10px;
        }
        .sidebar a:hover {
            background-color: #007bff;
            color: #fff;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .card {
            margin: 10px;
            border-radius: 10px;
        }
        .table-container {
        overflow-x: auto; /* Memastikan tabel dapat discroll secara horizontal jika terlalu lebar */
        white-space: nowrap; /* Mencegah teks memanjang ke bawah */
        margin-top: 20px;
         }
        .table th, .table td {
        text-align: center;
        padding: 10px;
        vertical-align: middle; /* Menengahkan konten secara vertikal */
        font-size: 14px; /* Ukuran teks lebih kecil untuk menghemat ruang */
         }
        .table th {
        background-color: #f1f1f1; /* Memberikan warna latar pada header tabel */
        font-weight: bold;
        }
        .sidebar a.active {
        background-color: #0056b3; /* Warna lebih gelap untuk menu terpilih */
        color: #fff; /* Teks putih */
        font-weight: bold; /* Teks lebih tebal */
         }
    .card-body {
        display: flex;
        flex-direction: column; /* Mengatur elemen dalam kolom */
        align-items: center;    /* Menengahkan secara horizontal */
        justify-content: center; /* Menengahkan secara vertikal */
        text-align: center;     /* Menengahkan teks */
        height: 150px;          /* Tinggi kotak untuk memastikan proporsional */
    }
    .card-body i {
        margin-bottom: 10px;    /* Jarak antara ikon dan teks */
        font-size: 3rem;        /* Ukuran ikon lebih besar */
    }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Human Resource Management</a>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <a href="#" class="active"><i class="fas fa-users"></i> Karyawan</a>
    <a href="#"><i class="fas fa-building"></i> Departemen</a>
    <a href="#"><i class="fas fa-briefcase"></i> Pekerjaan</a>
    <a href="#"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="#"><i class="fas fa-money-bill"></i> Penggajian</a>
</div>


<!-- Main Content -->
<div class="content">
    <h1><b>Dashboard Admin</b></h1>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-users text-primary"></i>
                    <h5 class="card-title fw-bold">Total Karyawan</h5>
                    <p class="card-text fw-bold">2</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-building text-success"></i>
                    <h5 class="card-title fw-bold">Departemen</h5>
                    <p class="card-text fw-bold">4</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-calendar-check text-info"></i>
                    <h5 class="card-title fw-bold">Hadir Hari Ini</h5>
                    <p class="card-text fw-bold">45</p>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mt-4">Data Karyawan</h2>
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No Telepon</th>
                    <th>Posisi</th>
                    <th>Departemen</th>
                    <th>Tanggal Perekrutan</th>
                    <th>Gaji</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>John Doe</td>
                    <td>john.doe@example.com</td>
                    <td>085795027431</td>
                    <td>Manager</td>
                    <td>HR</td>
                    <td>10-10-2024</td>
                    <td>Rp 4.000.000</td>
                    <td>
                        <button class="btn btn-success btn-sm">Tambah</button>
                        <button class="btn btn-primary btn-sm">Edit</button>
                        <button class="btn btn-danger btn-sm">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Jane Smith</td>
                    <td>jane.smith@example.com</td>
                    <td>085123456789</td>
                    <td>Developer</td>
                    <td>IT</td>
                    <td>11-11-2024</td>
                    <td>Rp 3.500.000</td>
                    <td>
                        <button class="btn btn-success btn-sm">Tambah</button>
                        <button class="btn btn-primary btn-sm">Edit</button>
                        <button class="btn btn-danger btn-sm">Hapus</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\UAS_HR_Management\resources\views/welcome.blade.php ENDPATH**/ ?>