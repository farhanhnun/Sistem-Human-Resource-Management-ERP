<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Riwayat Pekerjaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
        }
        .content {
            margin-left: 250px; /* Sesuaikan dengan lebar sidebar */
            padding: 20px;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
        }
        .sidebar a.active {
            background-color: #007bff;
            color: white;
        }
        .sidebar a:hover {
            background-color: #575757;
            color: white;
        }
    </style>
</head>
<body>
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="sidebar">
        <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
        <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
        <a href="<?php echo e(route('riwayatpekerjaan.index')); ?>" class="active"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
        <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
        <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
    </div>

    <div class="content">
        <div class="container bg-light p-5 rounded shadow-lg">
            <h2 class="mb-4 text-center"><b>Edit Riwayat Pekerjaan</b></h2>
            <form action="<?php echo e(route('riwayatpekerjaan.update', $riwayatPekerjaan->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row mb-3">
                    <label for="staff_id" class="col-sm-3 col-form-label">Nama Karyawan</label>
                    <div class="col-sm-9">
                        <select class="form-select" name="staff_id" id="staff_id" required>
                            <option value="" disabled>Pilih Karyawan</option>
                            <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($staff->id); ?>" <?php echo e($staff->id == $riwayatPekerjaan->staff_id ? 'selected' : ''); ?>>
                                    <?php echo e($staff->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="start_date" class="col-sm-3 col-form-label">Tanggal Mulai</label>
                    <div class="col-sm-9">
                        <input type="datetime-local" class="form-control" name="start_date" value="<?php echo e($riwayatPekerjaan->start_date); ?>" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="end_date" class="col-sm-3 col-form-label">Tanggal Selesai</label>
                    <div class="col-sm-9">
                        <input type="datetime-local" class="form-control" name="end_date" value="<?php echo e($riwayatPekerjaan->end_date); ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="department_id" class="col-sm-3 col-form-label">Nama Departemen</label>
                    <div class="col-sm-9">
                        <select class="form-select" name="department_id" id="department_id" onchange="updatePositions()" required>
                            <option value="" disabled>Pilih Departemen</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e($department->id == $riwayatPekerjaan->department_id ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="position" class="col-sm-3 col-form-label">Posisi</label>
                    <div class="col-sm-9">
                        <select class="form-select" name="position" id="position" required>
                            <option value="" disabled>Pilih Posisi</option>
                        </select>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-3">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="<?php echo e(route('riwayatpekerjaan.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-sign-out-alt"></i> Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<script>
    // Data Posisi berdasarkan Departemen
    const departmentPositions = {
        1: ['Manager', 'HR Generalist', 'HR Manager', 'Compensation and Benefits Specialist'],
        2: ['Manager', 'Accountant', 'Tax Specialist', 'Chief Financial Officer (CFO)'],
        3: ['Manager', 'Marketing Manager', 'Brand Manager', 'Digital Marketing Specialist', 'Social Media Manager'],
        4: ['Manager', 'Software Developer', 'Network Admin', 'Database Administrator', 'Data Analyst'],
    };

    // Fungsi untuk memperbarui opsi posisi berdasarkan departemen yang dipilih
    function updatePositions() {
        const departmentId = document.getElementById('department_id').value;
        const positionSelect = document.getElementById('position');
        const currentPosition = "<?php echo e($riwayatPekerjaan->position); ?>";

        // Kosongkan dropdown posisi
        positionSelect.innerHTML = '<option value="" disabled selected>Pilih Posisi</option>';

        if (departmentId && departmentPositions[departmentId]) {
            const positions = departmentPositions[departmentId];
            positions.forEach(function (position) {
                const option = document.createElement('option');
                option.value = position;
                option.textContent = position;

                // Tandai posisi yang sesuai dengan data sebelumnya
                if (position === currentPosition) {
                    option.selected = true;
                }

                positionSelect.appendChild(option);
            });
        }
    }

    // Panggil fungsi saat halaman dimuat untuk inisialisasi
    document.addEventListener('DOMContentLoaded', updatePositions);
</script>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/riwayatpekerjaan/edit.blade.php ENDPATH**/ ?>