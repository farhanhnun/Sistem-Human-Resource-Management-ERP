<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji" class="active"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content">
    <div class="container">
        <div class="row">
            <!-- Content -->
            <div class="col-md-6 col-lg-10">
                <div class="container my-4">
                    <!-- Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><b>Daftar Gaji Karyawan</b></h2>
                    </div>
                </div>
            </div>

            <!-- Total Gaji and Bonus Cards -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-money-bill-wave fa-2x text-success mb-2"></i>
                            <h5 class="card-title">Total Gaji Dibayarkan</h5>
                            <p class="card-text text-success fs-5 fw-bold">
                                Rp <?php echo e(number_format($total_gaji_dibayar, 0, ',', '.')); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-gift fa-2x text-warning mb-2"></i>
                            <h5 class="card-title">Total Bonus</h5>
                            <p class="card-text text-warning fs-5 fw-bold">
                                Rp <?php echo e(number_format($total_bonus, 0, ',', '.')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="d-flex justify-content-end mb-4">
                <a href="<?php echo e(route('payroll.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus me-2"></i> Tambah Gaji
                </a>
            </div>

            <!-- Tabel Gaji -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID Staff</th>
                            <th>Nama Staff</th>
                            <th>Tanggal Gaji</th>
                            <th>Gaji</th>
                            <th>Bonus</th>
                            <th>Potongan</th>
                            <th>Total Gaji Dibayarkan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payroll->staff_id); ?></td>
                                <td><?php echo e($payroll->staff_name); ?></td>
                                <td><?php echo e($payroll->pay_date); ?></td>
                                <td>Rp <?php echo e(number_format($payroll->amount, 0, ',', '.')); ?></td>
                                <td>Rp <?php echo e(number_format($payroll->bonus, 0, ',', '.')); ?></td>
                                <td>Rp <?php echo e(number_format($payroll->deduction, 0, ',', '.')); ?></td>
                                <td>Rp <?php echo e(number_format($payroll->amount + $payroll->bonus - $payroll->deduction, 0, ',', '.')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('payroll.edit', $payroll->payroll_id)); ?>" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <form action="<?php echo e(route('payroll.destroy', $payroll->payroll_id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/daftargaji/daftargaji.blade.php ENDPATH**/ ?>