<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

</head>
<body>
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan" class="active"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<!-- Main Content -->
<div class="content">
    <h1>Riwayat Pekerjaaan</h1>


    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Staff ID</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Position</th>
                    <th>Department</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>202302090</td>
                    <td>2023-01-01</td>
                    <td>2023-12-31</td>
                    <td>
                        <select class="form-select">
                        <option value="SP">Spesialis Perekrutan</option>
                        <option value="SHK">Spesialis Hubungan Karyawan</option>
                        </select>
                    </td>
                    <td>HR</td>
                    <td>
                    <button class="btn btn-success btn-sm">Add</button>
                    <button class="btn btn-primary btn-sm">  <i class="fas fa-edit"></i></button></button>
                    <button class="btn bttn-danger btn-sm">Hapus</button>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>202302080</td>
                    <td>2022-01-01</td>
                    <td>2023-01-01</td>
                    <td>
                        <select class="form-select">
                            <option value="DS">Data Scientist</option>
                            <option value="SDE">Software Department Engineer</option>
                        </select>
                    </td>
                    <td>IT</td>
                    <td>
                    <button class="btn btn-success btn-sm">Add</button>
                    <button class="btn btn-primary btn-sm">Edit</button>
                    <button class="btn btn-danger btn-sm">Hapus</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/riwayatpekerjaan.blade.php ENDPATH**/ ?>