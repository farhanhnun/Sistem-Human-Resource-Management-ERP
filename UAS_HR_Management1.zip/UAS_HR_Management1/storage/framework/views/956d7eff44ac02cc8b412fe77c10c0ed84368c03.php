<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<div class="content">
    <h2 class="mb-4">Edit attendance</h2>
    <div class="bg-light bg-gradient">
        <form action="<?php echo e(route('attendance.update',$attendance->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nama</label>
                <input type="hidden" class="form-control" name="name" placeholder="Nama"
                value="<?php echo e($attendance->staff_id); ?>" required>
                <input type="text" class="form-control" name="nameDisplay" placeholder="Nama"
                value="<?php echo e($attendance->staff->name); ?>" required>
              </div>
              <div class="mb-3">
                <label for="attendance_date" class="form-label">Tanggal</label>
                <input type="date" class="form-control" name="attendance_date" value="<?php echo e($attendance->attendance_date); ?>">
              </div>
              <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select type="text" name="status" class="form-control" value="<?php echo e($attendance->status); ?>">
                    <option value="Hadir">Hadir</option>    
                    <option value="Sakit">Sakit</option>    
                    <option value="Izin">Izin</option>    
                    <option value="Alpa">Alpa</option>    
                    </select>
              </div>
              <div class="d-flex justify-content-end"><button type="submit" class="btn btn-primary ">Submit</button></div>
        </form>
    </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\kuliah\UAS_HR_Management\resources\views/attendance/edit.blade.php ENDPATH**/ ?>