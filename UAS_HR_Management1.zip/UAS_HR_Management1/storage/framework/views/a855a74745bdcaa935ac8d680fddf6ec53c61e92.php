<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>" class="active"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content">

<div style="display: flex; justify-content: space-between; align-items: end;">
        <h2 class="mt-1"><b>Data Kehadiran Karyawan</b></h2>
    </div>

    <div class="container-fluid">
    <form class="d-flex align-items-center gap-4" action="<?php echo e(route('attendance.index')); ?>" method="GET" role="search">
            <input class="form-control" type="search" name="cari-nama" placeholder="Search by Name" aria-label="Search" style="width: 600px; font-weight: 200;">
            <input class="form-control" type="date" name="date" style="width: 300px; font-weight: 200;">
            <button class="btn btn-outline-success" type="submit">Search</button>

            <a href="<?php echo e(route('attendance.create')); ?>" class="btn btn-success">
                <i class="fas fa-calendar-check"></i> Input Kehadiran
            </a>
    </form>

        
    </div>

    
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Tanggal Absen</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->staff->name); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($item->attendance_date))); ?></td>
                    <td><?php echo e($item->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('attendance.edit',$item->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/attendance/kehadiran.blade.php ENDPATH**/ ?>