<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
</head>
<body>

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Content -->
<div class="content">
    <h2 class="mb-4">Add Karyawan</h2>
    <div class="bg-light bg-gradient">
        <form action="<?php echo e(route('karyawan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Karyawan</label>
                <input type="text" class="form-control" name="name" placeholder="Nama Karyawan" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Karyawan</label>
                <input type="email" class="form-control" name="email" placeholder="Email Karyawan">
            </div>
            <div class="mb-3">
                <label for="hide_date" class="form-label">Tanggal Masuk</label>
                <input type="date" class="form-control" name="hire_date">
            </div>
            <div class="mb-3">
                <label for="position" class="form-label">Posisi</label>
                <input type="text" class="form-control" name="position" placeholder="Posisi">
            </div>
            <div class="mb-3">
                <label for="department_name" class="form-label">Nama Departemen</label>
                <select class="form-control" name="department_id" required>
                    <option value="" disabled selected>Pilih Departemen</option>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>
            <div class="mb-3">
                <label for="salary" class="form-label">Gaji Karyawan</label>
                <input type="number" class="form-control" step="0.1" name="salary">
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
        
    </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\kuliah\UAS_HR_Management\resources\views/staff/add.blade.php ENDPATH**/ ?>