<div class="sidebar">
    <a href="<?php echo e(route('karyawan.index')); ?>" class="active"><i class="fas fa-users"></i> Karyawan</a>
    <a href="<?php echo e(route('department.index')); ?>"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="<?php echo e(route('attendance.index')); ?>"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div><?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/components/sidebar.blade.php ENDPATH**/ ?>