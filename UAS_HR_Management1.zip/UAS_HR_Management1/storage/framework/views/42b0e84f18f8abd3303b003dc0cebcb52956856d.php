<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fbfd;
        }

        /* Navbar Styling */
        .navbar {
            background-color: #1e3a8a; /* Biru tua modern */
            color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1020;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #283593, #3949ab);
            color: #fff;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            box-shadow: 2px 0px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: #e3f2fd;
            text-decoration: none;
            display: block;
            padding: 15px 20px;
            font-size: 1rem;
            border-radius: 5px;
            margin: 5px 10px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #1565c0;
            color: #fff;
        }

        .sidebar a.active {
            background-color: #1e88e5;
            color: #fff;
            font-weight: bold;
        }

        /* Content Area Styling */
        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .content h2 {
            margin-left: -10px;
            color: #1e3a8a;
        }

        /* Card Styling */
        .card {
            margin: 10px;
            border-radius: 12px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            height: 150px;
        }

        .card-body i {
            margin-bottom: 10px;
            font-size: 3rem;
        }

        .card-body i.fa-users {
            color: black; /* Warna biru */
        }

        .card-body i.fa-building {
            color: #66bb6a; /* Warna hijau */
        }

        .card-body i.fa-calendar-check {
            color: #4fc3f7; /* Warna oranye */
        }

        .card-body h5 {
            font-weight: bold;
            color: black;
        }

        .card-body p {
            font-size: 1.25rem;
            color: #616161;
        }

        /* Table Styling */
        .table-container {
            overflow-x: auto;
            white-space: nowrap;
            margin-top: 20px;
        }

        .table {
            border: 1px solid #ddd;
        }

        .table th {
            background-color: #e3f2fd;
            font-weight: bold;
            color: #1e3a8a;
        }

        .table td {
            color: #424242;
        }

        .table th, .table td {
            text-align: center;
            padding: 10px;
            vertical-align: middle;
            font-size: 14px;
        }
        .table-bordered {
        border: 1px solid #000; /* Garis luar tabel */
        }
        .table-bordered th, .table-bordered td {
        border: 1px solid #000; /* Garis dalam tabel */
        }
    </style>
</head>
<body>

<?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- Content -->
<div class="content">
    <h2 class="mb-4">Dashboard Amin</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-users"></i>
                    <h5>Total Karyawan</h5>
                    <p><b>2</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-building"></i>
                    <h5>Departemen</h5>
                    <p><b>4</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <i class="fas fa-calendar-check"></i>
                    <h5>Hadir Hari Ini</h5>
                    <p><b>45</b></p>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mt-4">Data Karyawan</h2>
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No Telepon</th>
                    <th>Posisi</th>
                    <th>Departemen</th>
                    <th>Tanggal Perekrutan</th>
                    <th>Gaji</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>202302090</td>
                    <td>John Doe</td>
                    <td>john.doe@example.com</td>
                    <td>085795027431</td>
                    <td>Manager</td>
                    <td>HR</td>
                    <td>10-10-2024</td>
                    <td>Rp 4.000.000</td>
                <td>
                    <button class="btn btn-success btn-sm">
                    <i class="fa-solid fa-user-plus"></i></button>
                    <button class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></button>
                    <button class="btn btn-danger btn-sm">
                    <i class="fas fa-trash"></i></button>
                </td>

                </tr>
                <tr>
                    <td>2023020</td>
                    <td>Jane Smith</td>
                    <td>jane.smith@example.com</td>
                    <td>085123456789</td>
                    <td>Developer</td>
                    <td>IT</td>
                    <td>11-11-2024</td>
                    <td>Rp 3.500.000</td>
                    <td>
                    <button class="btn btn-success btn-sm">
                    <i class="fa-solid fa-user-plus"></i></button>
                    <button class="btn btn-primary btn-sm">
                     <i class="fas fa-edit"></i></button>
                    <button class="btn btn-danger btn-sm">
                    <i class="fas fa-trash"></i></button>
                </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS_HR_Management1\resources\views/index.blade.php ENDPATH**/ ?>