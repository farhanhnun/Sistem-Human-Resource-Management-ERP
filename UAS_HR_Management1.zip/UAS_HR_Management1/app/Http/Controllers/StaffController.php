<?php

namespace App\Http\Controllers;

use App\Models\Departments;
use App\Models\Staffs;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $staffs = Staffs::all();
        $totalKaryawan = staffs::distinct('email')->count('email');
    return view('staff.staff', compact('staffs', 'totalKaryawan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $departments = Departments::all();
        return view('staff.add', compact('departments'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:staffs,email',
            'hire_date' => 'required|date',
            'position' => 'nullable|string|max:255',
            'department_id' => 'nullable',
            'salary' => 'nullable|numeric|min:0',
        ]);
        // Create the department/employee record
        Staffs::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'hire_date' => $request->input('hire_date'),
            'position' => $request->input('position'),
            'department_id' => $request->input('department_id'),
            'salary' => $request->input('salary'),
        ]);
        // Redirect with a success message
        return redirect()->route('karyawan.index')->with('success', 'Data berhasil disimpan!');
    }

     public function edit($id)
     {
         $staff = Staffs::findOrFail($id);
         $departments = Departments::all();
         return view('staff.edit', compact('staff', 'departments'));
     }
     
     public function update(Request $request, $id)
     {
         $staff = Staffs::findOrFail($id);
     
         // Validasi tanpa mewajibkan tanggal diisi
         $request->validate([
             'name' => 'nullable|string|max:255',
             'email' => 'nullable|email|unique:staffs,email,' . $staff->id,
             'hire_date' => 'nullable|date', // Tanggal boleh kosong
             'position' => 'nullable|string|max:255',
             'department_id' => 'nullable|exists:departments,id',
             'salary' => 'nullable|numeric|min:0',
         ]);
     
         // Update hanya field yang diisi (gunakan `only` untuk mengambil input yang ada)
         $staff->update($request->only([
             'name',
             'email',
             'hire_date',
             'position',
             'department_id',
             'salary',
         ]));
     
         return redirect()->route('karyawan.index')->with('success', 'Data berhasil diperbarui!');
     }

     public function getStaff($id)
{
    $staff = Staffs::find($id); // Cari staff berdasarkan ID
    if ($staff) {
        return response()->json([
            'name' => $staff->name,
            'salary' => $staff->salary,
        ]); // Kembalikan nama staff
    }
    return response()->json(null); // Jika tidak ditemukan
}
     

     

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
{
    $staff = Staffs::findOrFail($id);
    $staff->delete();

    return redirect()->route('karyawan.index')->with('success', 'Data berhasil dihapus!');
}
}
