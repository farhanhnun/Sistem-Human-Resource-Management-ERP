<?php

namespace App\Http\Controllers;

use App\Models\Departments;
use App\Models\RiwayatPekerjaan;
use App\Models\Staffs;
use Illuminate\Http\Request;

class RiwayatPekerjaanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $riwayatpekerjaan = RiwayatPekerjaan::with('staff','department')->get();
        return view('riwayatpekerjaan.riwayatpekerjaan', compact('riwayatpekerjaan'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $staffs = Staffs::all();
        $department = Departments::all();
        return view('riwayatpekerjaan.add', compact('staffs','department'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'staff_id' => 'required|integer',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'position' => 'required|string|max:255',
            'department_id' => 'required|integer',
        ]);

        // Simpan data ke database
        RiwayatPekerjaan::create([
            'staff_id' => $request->staff_id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'position' => $request->position,
            'department_id' => $request->department_id,
        ]);

        // Redirect setelah berhasil
        return redirect()->route('riwayatpekerjaan.index')->with('success', 'Data berhasil disimpan.');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $riwayatPekerjaan = RiwayatPekerjaan::with(['staff', 'department'])->findOrFail($id);

        // Ambil data staff dan department untuk dropdown
        $staffs = Staffs::all();
        $departments = Departments::all();

        return view('riwayatpekerjaan.edit', compact('riwayatPekerjaan', 'staffs', 'departments'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'staff_id' => 'required|integer',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'position' => 'required|string|max:255',
            'department_id' => 'required|integer',
        ]);

        // Temukan riwayat pekerjaan dan update
        $riwayatPekerjaan = RiwayatPekerjaan::findOrFail($id);
        $riwayatPekerjaan->update($request->all());

        // Redirect setelah berhasil
        return redirect()->route('riwayatpekerjaan.index')->with('success', 'Data berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $riwayatpekerjaan = RiwayatPekerjaan::findOrFail($id);
        $riwayatpekerjaan->delete();

        return redirect()->route('riwayatpekerjaan.index')->with('success', 'Data berhasil dihapus!');
    }
}