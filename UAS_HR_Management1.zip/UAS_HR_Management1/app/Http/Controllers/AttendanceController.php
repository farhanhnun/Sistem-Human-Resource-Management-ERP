<?php

namespace App\Http\Controllers;

use App\Models\Attendances;
use App\Models\Staffs;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // Validasi input
        $request->validate([
            'name' => 'nullable|string|max:255',
            'date' => 'nullable|date',
        ]);

        // Ambil input pencarian
        $name = $request->input('cari-nama');
        $date = $request->input('date');

        // Query pencarian atau tampilkan semua data
        $query = Attendances::query();

        if ($name) {
            $query->whereHas('staff', function ($q) use ($name) {
                $q->where('name', 'like', '%' . $name . '%');
            });
        }

        if ($date) {
            $query->whereDate('attendance_date', $date);
        }

        // Ambil hasil, default menampilkan semua jika tidak ada filter
        $attendance = $query->get();

        // Kirim hasil ke view
        return view('attendance.kehadiran', compact('attendance'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $staffs = Staffs::all();
        return view('attendance.add', compact('staffs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        // Validate incoming data
        $request->validate([
            'name' => 'required|array',
            'attendance_date' => 'required|array',
            'status' => 'required|array',
        ]);

        // Loop through each entry and create a new Attendance record
        foreach ($request->name as $index => $name) {
            Attendances::create([
                'staff_id' => $name, // Assuming name holds staff ID
                'attendance_date' => $request->attendance_date[$index],
                'status' => $request->status[$index],
            ]);
        }

        return redirect()->route('attendance.index')->with('success', 'Resource updated successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $attendance = Attendances::find($id);
        return view('attendance.edit', compact('attendance'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            // Define validation rules for your fields
            'name' => 'required|string',
            'attendance_date' => 'required',
            'status' => 'required',
        ]);
        $data = Attendances::findOrFail($id);
        $data->update([
            'staff_id' => $request->name,
            'attendance_date' => $request->attendance_date,
            'status' => $request->status,
        ]);
        return redirect()->route('attendance.index')->with('success', 'Resource updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
