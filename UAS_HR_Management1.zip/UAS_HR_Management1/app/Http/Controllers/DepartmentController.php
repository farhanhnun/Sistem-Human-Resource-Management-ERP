<?php

namespace App\Http\Controllers;

use App\Models\Departments;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $departments = Departments::with('manager')->get();

    return view('department.department', compact('departments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('department.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
{
    // Validasi input
    $request->validate([
        'nmDepart' => 'required|string|max:255',
        'manager_id' => 'nullable|exists:staffs,id', // Validasi manager_id harus sesuai dengan ID di tabel staffs
    ]);

    // Logika otomatis mencari manager jika tidak diisi
    $manager = $request->manager_id 
        ? Staff::find($request->manager_id) 
        : Staff::where('position', 'manager')->first();

    // Simpan data department
    Departments::create([
        'name' => $request->nmDepart,
        'manager_id' => $manager ? $manager->id : null, // Set manager_id jika ditemukan
    ]);

    return redirect()->route('department.index')->with('success', 'Department berhasil ditambahkan!');
}
    public function edit($id)
    {
        //
        $department = Departments::find($id);
        return view('department.edit', compact('department'));
    }

    public function update(Request $request, $id)
    {
        //
        $request->validate([
            // Define validation rules for your fields
            'nmDepart' => 'required|string',
            'manager_id' => 'nullable',
        ]);
        $data = Departments::findOrFail($id);
        $data->update([
            'name' => $request->nmDepart,
            'manager_id' => $request->manager_id,
        ]);
        return redirect()->route('department.index')->with('success', 'Resource updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $departments = Departments::findOrFail($id);
        $departments->delete();
    
        return redirect()->route('department.index')->with('success', 'Data berhasil dihapus!');
    }
}
