<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PayrollController extends Controller
{
    /**
     * Menampilkan daftar gaji.
     */
    public function index(Request $request)
    {
        // Menambahkan filter berdasarkan tanggal jika ada parameter dalam request
        $payrolls = DB::table('payrolls')
            ->join('staffs', 'payrolls.staff_id', '=', 'staffs.id')
            ->select(
                'payrolls.id as payroll_id',
                'payrolls.staff_id',
                'staffs.name as staff_name',
                'staffs.email',
                'payrolls.pay_date',
                'payrolls.amount',
                'payrolls.bonus',
                'payrolls.deduction',
                // Hitung total gaji yang dibayar (gaji + bonus - potongan)
                DB::raw('(payrolls.amount + payrolls.bonus - payrolls.deduction) as total_salary')
            );
    
        // Jika ada filter tanggal
        if ($request->has('start_date') && $request->has('end_date')) {
            $payrolls = $payrolls->whereBetween('payrolls.pay_date', [$request->start_date, $request->end_date]);
        }
    
        $payrolls = $payrolls->get();
    
        // Hitung total gaji, bonus, dan potongan
        $total_gaji = $payrolls->sum('amount');
        $total_bonus = $payrolls->sum('bonus');
        $total_deduction = $payrolls->sum('deduction');
        $total_gaji_dibayar = $payrolls->sum('total_salary'); // Total gaji yang dibayarkan
    
        // Return ke view dengan data payrolls dan total yang sudah dihitung
        return view('daftargaji.daftargaji', compact('payrolls', 'total_gaji', 'total_bonus', 'total_deduction', 'total_gaji_dibayar'));
    }
    

    /**
     * Menampilkan form untuk membuat gaji baru.
     */
    public function create()
    {
        // Mengambil data staff untuk form
        $staffs = DB::table('staffs')->get();

        // Tampilkan view untuk form tambah gaji
        return view('daftargaji.create', compact('staffs'));
    }

    /**
     * Menyimpan data gaji ke dalam database.
     */
    public function store(Request $request)
    {
        // Validasi data input
        $request->validate([
            'staff_id' => 'required|exists:staffs,id', // Pastikan ID staff ada di tabel staffs
            'pay_date' => 'required|date',            // Tanggal pembayaran harus valid
            'amount' => 'required|numeric',           // Jumlah gaji harus numerik
            'bonus' => 'required|numeric',            // Jumlah bonus harus numerik
            'deduction' => 'required|numeric',        // Jumlah potongan harus numerik
        ]);

        // Simpan data ke tabel payrolls
        DB::table('payrolls')->insert([
            'staff_id' => $request->staff_id,
            'pay_date' => $request->pay_date,
            'amount' => $request->amount,
            'bonus' => $request->bonus,
            'deduction' => $request->deduction,
        ]);

        // Redirect ke halaman daftar gaji dengan pesan sukses
        return redirect()->route('payroll.index')->with('success', 'Gaji berhasil ditambahkan!');
    }

    /**
 * Menampilkan form untuk mengedit gaji.
 */
public function edit($id)
{
    // Ambil data payroll berdasarkan ID
    $payroll = DB::table('payrolls')->where('id', $id)->first();

    // Ambil data staff untuk dropdown
    $staffs = DB::table('staffs')->get();

    // Jika data payroll tidak ditemukan, tampilkan halaman error atau redirect
    if (!$payroll) {
        return redirect()->route('payroll.index')->with('error', 'Data gaji tidak ditemukan.');
    }

    // Tampilkan view dengan data payroll dan staff
    return view('daftargaji.edit', compact('payroll', 'staffs'));
}


/**
 * Memproses pembaruan gaji.
 */
/**
 * Memproses pembaruan gaji.
 */
public function update(Request $request, $id)
{
    // Validasi data input
    $request->validate([
        'staff_id' => 'required|exists:staffs,id', // Validasi ID staff
        'pay_date' => 'required|date', // Validasi tanggal
        'amount' => 'required|numeric', // Validasi jumlah gaji
        'bonus' => 'required|numeric', // Validasi jumlah bonus
        'deduction' => 'required|numeric', // Validasi jumlah potongan
    ]);

    // Update data payroll di tabel payrolls
    $updated = DB::table('payrolls')->where('id', $id)->update([
        'staff_id' => $request->staff_id,
        'pay_date' => $request->pay_date,
        'amount' => $request->amount,
        'bonus' => $request->bonus,
        'deduction' => $request->deduction,
    ]);

    // Cek apakah update berhasil
    if ($updated) {
        return redirect()->route('payroll.index')->with('success', 'Gaji berhasil diperbarui!');
    }

    return redirect()->route('payroll.index')->with('error', 'Gagal memperbarui gaji.');
}

public function destroy($id)
{
    // Cari data payroll berdasarkan ID
    $payroll = DB::table('payrolls')->where('id', $id)->first();

    // Jika data tidak ditemukan, redirect dengan pesan error
    if (!$payroll) {
        return redirect()->route('payroll.index')->with('error', 'Data gaji tidak ditemukan.');
    }

    // Hapus data payroll
    DB::table('payrolls')->where('id', $id)->delete();

    // Redirect ke halaman daftar gaji dengan pesan sukses
    return redirect()->route('payroll.index')->with('success', 'Gaji berhasil dihapus!');
}

}
