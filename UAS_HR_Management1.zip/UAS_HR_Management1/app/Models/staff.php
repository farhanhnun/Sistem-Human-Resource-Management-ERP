<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;

    protected $fillable = [
        'id', 
        'name', 
        'email', 
        'hire_date', 
        'position', 
        'department_id', 
        'salary',
    ];

    /**
     * Relasi ke Department (opsional jika diperlukan).
     */
    public function department()
    {
        return $this->hasOne(Departments::class, 'manager_id', 'id');
    }

    public function payrolls()
    {
    return $this->hasMany(Payroll::class, 'staff_id');
    }

    
}