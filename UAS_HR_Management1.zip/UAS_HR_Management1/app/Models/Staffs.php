<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Staffs extends Model
{
    // use HasFactory;
    protected $table = 'staffs';
    protected $fillable = [
        'name',
        'email',
        'hire_date',
        'position',
        'department_id',
        'salary',
    ];





    public function department()
    {
        return $this->belongsTo(Departments::class);
    }
}
