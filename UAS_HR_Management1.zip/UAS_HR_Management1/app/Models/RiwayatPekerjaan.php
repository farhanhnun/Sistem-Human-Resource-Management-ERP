<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiwayatPekerjaan extends Model
{
    use HasFactory;

    // Tentukan nama tabel jika berbeda dari nama model jamak
    protected $table = 'job_historys';

    // Tentukan kolom yang dapat diisi
    protected $fillable = [
        'staff_id',
        'start_date',
        'end_date',
        'position',
        'department_id',
    ];

    // Relasi dengan model Department
    public function department()
    {
        return $this->belongsTo(Departments::class); // Pastikan nama model sesuai
    }
    public function staff()
    {
        return $this->belongsTo(Staffs::class, 'staff_id');
    }
}