<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payroll extends Model
{
    use HasFactory;

    // Kolom yang dapat diisi secara massal
    protected $fillable = [
        'staff_id',
        'pay_date',
        'amount',
        'bonus',
        'deduction',
    ];

    // Relasi ke model Staff
    public function staff()
    {
        return $this->belongsTo(Staff::class); //Relasi ini menunjukkan 
        // bahwa setiap data di tabel payrolls berkaitan dengan satu data di tabel staffs.
    }
}
