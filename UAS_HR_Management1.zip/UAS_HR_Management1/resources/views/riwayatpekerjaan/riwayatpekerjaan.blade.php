<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

</head>
<body>
    @include('components.navbar')
    <div class="sidebar">
    <a href="{{route('karyawan.index')}}"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{route('department.index')}}"><i class="fas fa-building"></i> Departemen</a>
    <a href="{{route('riwayatpekerjaan.index')}}" class="active"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{route('attendance.index')}}"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<!-- Main Content -->
<div class="content">
    <h2><b>Riwayat Pekerjaaan</b></h2>
    @foreach($riwayatpekerjaan as $jobHistory)
    <input type="hidden" value="{{ $jobHistory->id }}">
    @endforeach

    <div class="table-container">
        <a href="{{ route('riwayatpekerjaan.add') }}" class="btn btn-sm  btn-success float-end me-2"><i class="fa fa-plus"></i> Tambah</a>
       <table class="table table-bordered mt-5">
    <thead>
        <tr>
            <th>Nama Karyawan</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Position</th>
            <th>Department</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach($riwayatpekerjaan as $jobHistory)
            <tr>
                 <td>{{ $jobHistory->staff->name ?? 'N/A' }}</td>
                <td>{{ $jobHistory->start_date }}</td>
                <td>{{ $jobHistory->end_date }}</td>
                <td>{{ $jobHistory->position }}</td>
                <td>{{ $jobHistory->department->name }}</td>
                <td>
                    <a href="{{ route('riwayatpekerjaan.edit', $jobHistory->id) }}" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>

                    <form action="{{ route('riwayatpekerjaan.destroy', $jobHistory->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus riwayat pekerjaan ini?');"><i class="fas fa-trash"></i> Hapus</button>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
    </div>
</div>
</div>