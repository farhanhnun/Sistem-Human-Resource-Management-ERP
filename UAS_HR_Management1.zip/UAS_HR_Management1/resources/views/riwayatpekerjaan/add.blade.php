<!DOCTYPE html>
<html>
<head>
    <title>Tambah Riwayat Pekerjaan</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script>
        function updatePositionAndDepartment() {
            var select = document.getElementById("staff_id");
            var selectedOption = select.options[select.selectedIndex];
            var position = selectedOption.getAttribute("data-position");
            var department = selectedOption.getAttribute("data-department");

            document.getElementById("position").value = position;
            document.getElementById("department_id").value = department;
        }
    </script>
</head>
<body>
    @include('components.navbar')
    <div class="sidebar">
    <a href="{{route('karyawan.index')}}"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{route('department.index')}}"><i class="fas fa-building"></i> Departemen</a>
    <a href="{{route('riwayatpekerjaan.index')}}" class="active"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{route('attendance.index')}}"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

    <!-- Main Content -->
    <div class="content mt-1">
        <h2 class="mb-2 text-center"><b>Tambah Riwayat Pekerjaan</b></h2>
        <div class="container bg-light p-5 rounded shadow-lg">
            <form action="{{ route('riwayatpekerjaan.store') }}" method="POST">
                @csrf

                <div class="row mb-3">
                    <label for="staff_id" class="col-sm-3 col-form-label">Staff</label>
                    <div class="col-sm-9">
                        <select id="staff_id" name="staff_id" class="form-select" onchange="updatePositionAndDepartment()" required>
                            <option value="" disabled selected>Pilih Staff</option>
                            @foreach($staffs as $staff)
                                <option value="{{ $staff->id }}" data-position="{{ $staff->position }}" data-department="{{ $staff->department_id }}">
                                    {{ $staff->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="start_date" class="col-sm-3 col-form-label">Tanggal Mulai</label>
                    <div class="col-sm-9">
                        <input type="datetime-local" name="start_date" class="form-control" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="end_date" class="col-sm-3 col-form-label">Tanggal Selesai</label>
                    <div class="col-sm-9">
                        <input type="datetime-local" name="end_date" class="form-control">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="position" class="col-sm-3 col-form-label">Posisi</label>
                    <div class="col-sm-9">
                        <input type="text" id="position" name="position" class="form-control" required readonly>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="department_id" class="col-sm-3 col-form-label">ID Departemen</label>
                    <div class="col-sm-9">
                        <input type="number" id="department_id" name="department_id" class="form-control" required readonly>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-3">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="{{ route('riwayatpekerjaan.index') }}" class="btn btn-secondary">
                        <i class="fas fa-sign-out-alt"></i> Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
