<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

@include('components.navbar')

<div class="sidebar">
    <a href="{{ route('karyawan.index') }}"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{ route('department.index') }}"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{ route('attendance.index') }}"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji" class="active"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content">
    <div class="container">
        <div class="row">
            <!-- Content -->
            <div class="col-md-6 col-lg-10">
                <div class="container my-4">
                    <!-- Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2><b>Daftar Gaji Karyawan</b></h2>
                    </div>
                </div>
            </div>

            <!-- Total Gaji and Bonus Cards -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-money-bill-wave fa-2x text-success mb-2"></i>
                            <h5 class="card-title">Total Gaji Dibayarkan</h5>
                            <p class="card-text text-success fs-5 fw-bold">
                                Rp {{ number_format($total_gaji_dibayar, 0, ',', '.') }}
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body text-center">
                            <i class="fas fa-gift fa-2x text-warning mb-2"></i>
                            <h5 class="card-title">Total Bonus</h5>
                            <p class="card-text text-warning fs-5 fw-bold">
                                Rp {{ number_format($total_bonus, 0, ',', '.') }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="d-flex justify-content-end mb-4">
                <a href="{{ route('payroll.create') }}" class="btn btn-success">
                    <i class="fas fa-plus me-2"></i> Tambah Gaji
                </a>
            </div>

            <!-- Tabel Gaji -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID Staff</th>
                            <th>Nama Staff</th>
                            <th>Tanggal Gaji</th>
                            <th>Gaji</th>
                            <th>Bonus</th>
                            <th>Potongan</th>
                            <th>Total Gaji Dibayarkan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($payrolls as $payroll)
                            <tr>
                                <td>{{ $payroll->staff_id }}</td>
                                <td>{{ $payroll->staff_name }}</td>
                                <td>{{ $payroll->pay_date }}</td>
                                <td>Rp {{ number_format($payroll->amount, 0, ',', '.') }}</td>
                                <td>Rp {{ number_format($payroll->bonus, 0, ',', '.') }}</td>
                                <td>Rp {{ number_format($payroll->deduction, 0, ',', '.') }}</td>
                                <td>Rp {{ number_format($payroll->amount + $payroll->bonus - $payroll->deduction, 0, ',', '.') }}</td>
                                <td>
                                    <a href="{{ route('payroll.edit', $payroll->payroll_id) }}" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <form action="{{ route('payroll.destroy', $payroll->payroll_id) }}" method="POST" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
