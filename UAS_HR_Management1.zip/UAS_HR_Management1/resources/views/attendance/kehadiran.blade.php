<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

@include('components.navbar')

<div class="sidebar">
    <a href="{{route('karyawan.index')}}"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{route('department.index')}}"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{route('attendance.index')}}" class="active"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content">

<div style="display: flex; justify-content: space-between; align-items: end;">
        <h2 class="mt-1"><b>Data Kehadiran Karyawan</b></h2>
    </div>

    <div class="container-fluid">
    <form class="d-flex align-items-center gap-4" action="{{ route('attendance.index') }}" method="GET" role="search">
            <input class="form-control" type="search" name="cari-nama" placeholder="Search by Name" aria-label="Search" style="width: 600px; font-weight: 200;">
            <input class="form-control" type="date" name="date" style="width: 300px; font-weight: 200;">
            <button class="btn btn-outline-success" type="submit">Search</button>

            <a href="{{route('attendance.create')}}" class="btn btn-success">
                <i class="fas fa-calendar-check"></i> Input Kehadiran
            </a>
    </form>

        
    </div>

    
    <div class="table-container">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Tanggal Absen</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($attendance as $item)
                <tr>
                    <td>{{$loop->iteration}}</td>
                    <td>{{$item->staff->name}}</td>
                    <td>{{ date('d-m-Y', strtotime($item->attendance_date)) }}</td>
                    <td>{{$item->status}}</td>
                    <td>
                        <a href="{{ route('attendance.edit',$item->id)}}" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
