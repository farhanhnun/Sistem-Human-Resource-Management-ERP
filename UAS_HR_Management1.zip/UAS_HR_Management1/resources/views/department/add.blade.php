<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fbfd;
        }

        /* Navbar Styling */
        .navbar {
            background-color: #1e3a8a; /* Biru tua modern */
            color: #fff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1020;
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #283593, #3949ab);
            color: #fff;
            position: fixed;
            height: 100%;
            padding-top: 20px;
            box-shadow: 2px 0px 6px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: #e3f2fd;
            text-decoration: none;
            display: block;
            padding: 15px 20px;
            font-size: 1rem;
            border-radius: 5px;
            margin: 5px 10px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #1565c0;
            color: #fff;
        }

        .sidebar a.active {
            background-color: #1e88e5;
            color: #fff;
            font-weight: bold;
        }

        /* Content Area Styling */
        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .content h2 {
            margin-left: -10px;
            color: #1e3a8a;
        }

        /* Card Styling */
        .card {
            margin: 10px;
            border-radius: 12px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            height: 150px;
        }

        .card-body i {
            margin-bottom: 10px;
            font-size: 3rem;
        }

        .card-body i.fa-user-tie    {
            color: black; /* Warna biru */
        }

        .card-body i.fa-coins {
            color: gold; /* Warna hijau */
        }

        .card-body i.fa-bullhorn {
            color: red; /* Warna oranye */
        }

        .card-body i.fa-laptop-code {
            color: blueviolet; /* Warna oranye */
        }

        .card-body h6 {
            font-weight: bold;
            color: black;
        }

        .card-body p {
            font-size: 1.25rem;
            color: #616161;
        }

        /* Table Styling */
        .table-container {
            overflow-x: auto;
            white-space: nowrap;
            margin-top: 20px;
        }

        .table {
            border: 1px solid #ddd;
        }

        .table th {
            background-color: #e3f2fd;
            font-weight: bold;
            color: #1e3a8a;
        }

        .table td {
            color: #424242;
        }

        .table th, .table td {
            text-align: center;
            padding: 10px;
            vertical-align: middle;
            font-size: 14px;
        }
        .table-bordered {
        border: 1px solid #000; /* Garis luar tabel */
        }
        .table-bordered th, .table-bordered td {
        border: 1px solid #000; /* Garis dalam tabel */
        }
    </style>
</head>
<body>

    @include('components.navbar')
    @include('components.sidebar')
    
<div class="content">
    <h2 class="mb-4">Add Department</h2>
    <div class="bg-light bg-gradient">
        <form action="{{ route('department.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="nmDepart" class="form-label">Nama Department</label>
                <input type="text" class="form-control" name="nmDepart" id="formGroupExampleInput" placeholder="Nama Department" required>
              </div>
              <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Nama Manager</label>
                <input type="text" class="form-control" placeholder="Nama Manager">
                <input type="hidden" class-- ------------------------------ Table structure for attendances-- ----------------------------DROP TABLE IF EXISTS `attendances`;="form-control" name="manager_id">
              </div>
              <div class="d-flex justify-content-end"><button type="submit" class="btn btn-primary ">Submit</button></div>
        </form>
    </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>