<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Department</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

@include('components.navbar')

<div class="sidebar">
    <a href="{{ route('karyawan.index') }}"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{ route('department.index') }}" class="active"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{ route('attendance.index') }}"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>

<div class="content mt-1">
    <h2 class="mb-2 text-center"><b>Edit Department</b></h2>
    <div class="container bg-light p-5 rounded shadow-lg">
        <form action="{{ route('department.update', $department->id) }}" method="POST">
            @csrf
            @method('PUT')

            <!-- Nama Department -->
            <div class="row mb-3">
                <label for="nmDepart" class="col-sm-3 col-form-label">Nama Department</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="nmDepart" name="nmDepart" value="{{ $department->name }}" placeholder="Nama Department" required>
                </div>
            </div>

            <!-- Nama Manager -->
            <div class="row mb-3">
                <label for="manager_id" class="col-sm-3 col-form-label">Nama Manager</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" name="manager_id" value="{{ $department->manager_id }}" placeholder="Nama Manager" required>
                    <input type="hidden" name="manager_id" value="{{ $department->manager_id }}">
                </div>
            </div>

            <div class="d-flex justify-content-end gap-3">
                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Submit</button>
                <a href="{{ route('department.index') }}" class="btn btn-secondary"><i class="fas fa-sign-out-alt"> </i>Kembali</a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
