<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

    @include('components.navbar')
    @include('components.sidebar')

    <!-- Main Content -->
    <div class="content mt-1">
        <h2 class="mb-2 text-center"><b>Edit Data Karyawan</b></h2>
        <div class="container bg-light p-5 rounded shadow-lg">
            <form action="{{ route('karyawan.update', $staff->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="row mb-3">
                    <label for="name" class="col-sm-3 col-form-label">Nama Karyawan</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="name" value="{{ $staff->name }}" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="email" class="col-sm-3 col-form-label">Email Karyawan</label>
                    <div class="col-sm-9">
                        <input type="email" class="form-control" name="email" value="{{ $staff->email }}" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="hire_date" class="col-sm-3 col-form-label">Tanggal Masuk</label>
                    <div class="col-sm-3">
                        <input type="date" class="form-control" name="hire_date" value="{{ $staff->hire_date }}">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="department_id" class="col-sm-3 col-form-label">Nama Departemen</label>
                    <div class="col-sm-9">
                        <select class="form-select" name="department_id" id="department_id" onchange="updatePositions()" required>
                            <option value="" disabled>Pilih Departemen</option>
                            @foreach ($departments as $department)
                                <option value="{{ $department->id }}" {{ $staff->department_id == $department->id ? 'selected' : '' }}>
                                    {{ $department->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="position" class="col-sm-3 col-form-label">Posisi</label>
                        <div class="col-sm-9">
                            <select class="form-select" name="position" id="position" required>
                             <option value="" disabled>Pilih Posisi</option>
                             <option value="{{ $staff->position }}" selected>{{ $staff->position }}</option>
                            </select>
                        </div>
                </div>

                <div class="row mb-3">
                    <label for="salary" class="col-sm-3 col-form-label">Gaji Karyawan</label>
                    <div class="col-sm-9">
                        <input type="number" class="form-control" name="salary" value="{{ $staff->salary }}">
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-3">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                    <a href="{{ route('karyawan.index') }}" class="btn btn-secondary">
                            <i class="fas fa-sign-out-alt"></i> Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script>
    // Data Posisi berdasarkan Departemen
    const departmentPositions = {
        1: ['Manager', 'HR Generalist', 'HR Manager', 'Compensation and Benefits Specialist'],
        2: ['Manager', 'Accountant', 'Tax Specialist', 'Chief Financial Officer (CFO)'],
        3: ['Manager', 'Marketing Manager', 'Brand Manager', 'Digital Marketing Specialist', 'Social Media Manager'],
        4: ['Manager', 'Software Developer', 'Network Admin', 'Database Administrator', 'Data Analyst'],
    };

    // Fungsi untuk memperbarui opsi posisi berdasarkan departemen yang dipilih
    function updatePositions() {
        const departmentId = document.getElementById('department_id').value;
        const positionSelect = document.getElementById('position');
        const currentPosition = "{{ $staff->position }}";

        // Kosongkan dropdown posisi
        positionSelect.innerHTML = '<option value="" disabled selected>Pilih Posisi</option>';

        if (departmentId && departmentPositions[departmentId]) {
            const positions = departmentPositions[departmentId];
            positions.forEach(function (position) {
                const option = document.createElement('option');
                option.value = position;
                option.textContent = position;

                // Tandai posisi yang sesuai dengan data sebelumnya
                if (position === currentPosition) {
                    option.selected = true;
                }

                positionSelect.appendChild(option);
            });
        }
    }

    // Panggil fungsi saat halaman dimuat untuk inisialisasi
    document.addEventListener('DOMContentLoaded', updatePositions);
</script>