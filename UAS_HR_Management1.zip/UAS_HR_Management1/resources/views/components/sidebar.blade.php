<div class="sidebar">
    <a href="{{route('karyawan.index')}}" class="active"><i class="fas fa-users"></i> Karyawan</a>
    <a href="{{route('department.index')}}"><i class="fas fa-building"></i> Departemen</a>
    <a href="/riwayatpekerjaan"><i class="fas fa-briefcase"></i> Riwayat Pekerjaan</a>
    <a href="{{route('attendance.index')}}"><i class="fas fa-calendar-check"></i> Kehadiran</a>
    <a href="/daftargaji"><i class="fas fa-money-bill"></i> Daftar Gaji</a>
</div>