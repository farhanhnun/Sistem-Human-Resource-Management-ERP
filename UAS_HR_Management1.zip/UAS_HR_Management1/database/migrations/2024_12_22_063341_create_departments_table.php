<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('departments', function (Blueprint $table) {
            $table->string('id', 20)->primary(); // Primary Key
            $table->string('name', 255); // Panjang name diperbesar
            $table->string('manager_id', 20)->nullable(); // Nullable untuk manager
            $table->foreign('manager_id')->references('id')->on('staffs')->onDelete('set null'); // Foreign Key ke staffs
            $table->timestamps(); // Menambahkan created_at dan updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('departments');
    }
};
