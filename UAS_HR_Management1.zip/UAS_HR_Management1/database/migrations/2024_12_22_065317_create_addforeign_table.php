<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('departments', function (Blueprint $table) {
            // Menambahkan kolom manager_id (jika belum ada)
            $table->string('manager_id', 20)->nullable();

            // Menambahkan foreign key ke tabel `staffs`
            $table->foreign('manager_id')->references('id')->on('staffs')->onDelete('set null');
        });

        // Menambahkan foreign key ke tabel `staffs`
        Schema::table('staffs', function (Blueprint $table) {
            // Menambahkan foreign key ke tabel `departments`
            $table->foreign('department_id')->references('id')->on('departments')->onDelete('cascade');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addforeign');
    }
};
