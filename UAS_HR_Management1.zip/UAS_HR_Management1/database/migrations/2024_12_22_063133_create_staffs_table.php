<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('staffs', function (Blueprint $table) {
            $table->string('id', 20)->primary(); // Primary Key
            $table->string('name', 255); // Panjang name diperbesar
            $table->string('email', 255)->unique(); // Email unik
            $table->date('hire_date'); // Tanggal hire
            $table->string('position', 255); // Panjang position diperbesar
            $table->string('department_id', 20)->nullable(); // Nullable department jika tidak memiliki departemen
            $table->integer('salary'); // Gaji
            $table->foreign('department_id')->references('id')->on('departments')->onDelete('cascade'); // Foreign Key ke departments
            $table->timestamps(); // Menambahkan created_at dan updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('staffs');
    }
};
